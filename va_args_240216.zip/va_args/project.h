/* -*- C -*- */
/* project.h */
/* erzeugt Freitag, 16. Februar 2024 12:26 (C) 2024 von Leander Jedamus */
/* modifiziert Freitag, 16. Februar 2024 12:53 von Leander Jedamus */

#ifndef PROJECT_H
#define PROJECT_H 1

#define PROJECT "va_args"

#endif /* PROJECT_H */

/* vim:set cindent ai sw=2 */

