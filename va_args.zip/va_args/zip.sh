#!/usr/bin/env sh

# erzeugt Donnerstag, 02. November 2023 22:07 (C) 2023 von Leander Jedamus
# modifiziert Mittwoch, 08. November 2023 07:34 von Leander Jedamus
# modifiziert Dienstag, 07. November 2023 18:05 von Leander Jedamus
# modifiziert Sonntag, 05. November 2023 08:42 von Leander Jedamus
# modifiziert Samstag, 04. November 2023 22:30 von Leander Jedamus
# modifiziert Donnerstag, 02. November 2023 23:42 von Leander Jedamus

# set -x

locale=locale
BACKUPDIR=$1
ZIPFILE=$2
backup=$(mktemp -d)
shift
shift
FILES=$*

trap "rm -rf $backup; exit" EXIT

rm -rf $backup
mkdir -p $backup/$BACKUPDIR
echo "copying files."
cp -p $FILES $backup/$BACKUPDIR
cp -Rp $locale $backup/$BACKUPDIR

actual_dir=$(pwd)

DIRS="$BACKUPDIR/$locale/*"
for language in de en; do
  DIRS="$DIRS $BACKUPDIR/$locale/$language/LC_MESSAGES/*"
done

cd $backup
echo "creating zip-file."
zip $ZIPFILE $BACKUPDIR/* $DIRS
mv $ZIPFILE $actual_dir
cd ..

# vim:ai sw=2

