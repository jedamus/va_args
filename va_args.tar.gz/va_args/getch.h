/* -*- C -*- */
/* getch.h */
/* erzeugt Donnerstag, 07. September 2023 16:02 (C) 2023 von Leander Jedamus */
/* modifiziert Donnerstag, 07. September 2023 16:19 von Leander Jedamus */

#ifndef GETCH_H
#define GETCH_H 1

extern int getch(void);

#endif /* GETCH_H */

/* vim:set cindent ai sw=2 */

