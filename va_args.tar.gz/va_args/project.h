/* -*- C -*- */
/* project.h */
/* erzeugt Montag, 12. August 2024 10:23 (C) 2024 von Leander Jedamus */
/* modifiziert Montag, 12. August 2024 10:23 von Leander Jedamus */

#ifndef PROJECT_H
#define PROJECT_H 1

#define PROJECT "va_args"
#define AUTHOR "Leander Jedamus"
#define EMAIL "ljedamus@web.de"
#define YEARS "2024"

#endif /* PROJECT_H */

/* vim:set cindent ai sw=2 */

