/* -*- C -*- */
/* getlocaledir.h */
/* erzeugt Montag, 14. August 2023 08:33 (C) 2023 von Leander Jedamus */
/* modifiziert Samstag, 02. September 2023 11:19 von Leander Jedamus */
/* modifiziert Montag, 28. August 2023 08:27 von Leander Jedamus */
/* modifiziert Montag, 14. August 2023 08:48 von Leander Jedamus */

#ifndef GETLOCALEDIR_H
#define GETLOCALEDIR_H 1

extern char *getlocaledir(CONST char *arg);

#endif /* GETLOCALEDIR_H */

/* vim:set cindent ai sw=2 */

